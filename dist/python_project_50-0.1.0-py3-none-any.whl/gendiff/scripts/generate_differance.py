from gendiff.cli import parser


def main():
    parser()


if __name__ == '__main__':
    main()