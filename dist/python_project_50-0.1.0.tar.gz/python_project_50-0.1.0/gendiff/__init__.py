from gendiff.gendiff import get_extension


__all__ = ('generate_diff',)
