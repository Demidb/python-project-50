import json


def json_form(data):
    return json.dumps(data, indent=4)
