### Hexlet tests and linter status:
[![Actions Status](https://github.com/Demidb/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-50/actions)

### Github Actions
[![hexlet-check](https://github.com/Demidb/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-50/actions/workflows/hexlet-check.yml)

### Maintainability Badge
[![Maintainability](https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/maintainability)](https://codeclimate.com/github/Demidb/python-project-50/maintainability)

### Test Coverage Badge
<a href="https://codeclimate.com/github/Demidb/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/test_coverage" /></a>
