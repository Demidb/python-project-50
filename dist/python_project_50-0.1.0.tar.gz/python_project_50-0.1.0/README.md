### Hexlet tests and linter status:
[![Actions Status](https://github.com/Demidb/python-project-50/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Demidb/python-project-50/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/maintainability)](https://codeclimate.com/github/Demidb/python-project-50/maintainability)

<a href="https://codeclimate.com/github/Demidb/python-project-50/test_coverage"><img src="https://api.codeclimate.com/v1/badges/fca6b4618e70a644cdb8/test_coverage" /></a>